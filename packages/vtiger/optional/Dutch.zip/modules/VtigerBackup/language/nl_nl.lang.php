<?php
/*+*******************************************************************************
 *  The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * Vertaling door Weltevree.org  www.weltevree.org
 *********************************************************************************/

/**
 * @author MAK
 */

$mod_strings = array(
	'LBL_CREATE_ZIP_FAILURE' => 'Maken Zip bestand Mislukt',
	'LBL_ZIP_FILE_ADD_FAILURE' => 'Toevoegen bestand Mislukt',
	'LBL_FTP_CONNECT_FAILED' => 'FTP connectie Mislukt',
	'LBL_FTP_LOGIN_FAILED' => 'FTP login Mislukt',
);

?>

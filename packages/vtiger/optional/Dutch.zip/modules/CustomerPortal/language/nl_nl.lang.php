<?php
/** Uw LICENTIE TEKST HIER **/
$mod_strings = Array (
'CustomerPortal' => 'Klanten Portaal',
'LBL_BASIC_SETTINGS'=>'Standaard Instellingen',
'LBL_ADVANCED_SETTINGS'=>'Geavanceerde Instellingen',
'LBL_MODULE'=>'Module',
'LBL_VIEW_ALL_RECORD'=>'Bekijk Alle Gerelateerde Records?',
'YES'=>'Ja',
'NO'=>'Nee',
'LBL_USER_DESCRIPTION'=>'Bovenstaand geselecteerde Gebruikers profiel zal geselecteerd worden ter controle van weergegeven velden in het Klanten Portaal. U Kunt de velden activeren/deactiveren die worden weergegeven in het Klanten Portaal.',
'SELECT_USERS'=>'Selecteer de Gebruikers',				
'LBL_DISABLE'=>'Activeer',
'LBL_ENABLE' =>'Deactiveer',
'Module' => 'Module',
'Sequence' =>'Sequentie',
'Visible'=>'Zichtbaar'

);

?>

<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'Webforms' => 'Webformulieren',
'LBL_SUCCESS' => 'Inhoud is toegevoegd aan vtiger CRM.',
'LBL_FAILURE' => 'Toevoegen inhoud MISLUKT.',
'LBL_ERROR_CODE' => 'Fout Code',
'LBL_ERROR_MESSAGE' => 'Fout Bericht'
);

?>

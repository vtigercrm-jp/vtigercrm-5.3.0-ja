<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'Webforms' => 'Webforms',
'LBL_SUCCESS' => 'entry is added to vtiger CRM.',
'LBL_FAILURE' => 'Failed to add entry in to vtiger CRM.',
'LBL_ERROR_CODE' => 'Error Code',
'LBL_ERROR_MESSAGE' => 'Error Message'
);

?>

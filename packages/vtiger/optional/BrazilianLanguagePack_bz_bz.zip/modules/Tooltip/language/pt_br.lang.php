<?php
/*********************************************************************************
** The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
* Contributor: Valmir Carlos Trindade | 30/12/2010 - www.ttcasolucoes.com.br
 ********************************************************************************/

$mod_strings = Array (
'Tooltip' => 'Dica Contexto',
'LBL_TOOLTIP_MANAGEMENT'=>'Administrar Dica Contexto',
'LBL_TOOLTIP_MANAGEMENT_DESCRIPTION'=>'Administrar Informações Dica Contexto aqui',
'LBL_FIELDS_IN'=>'Campos em',
'LBL_TOOLTIP_HELP_TEXT'=>'Selecione os campos que você gostaria que aparecessem na Dica Contexto',
'LBL_FIELD'=>'Campo',

);

?>

<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'Webforms' => 'Webforms',
'LBL_SUCCESS' => 'entrada adicionada no vtiger CRM.',
'LBL_FAILURE' => 'Entrada a ser adicionada no vtiger CRM falhou.',
'LBL_ERROR_CODE' => 'Código Erro',
'LBL_ERROR_MESSAGE' => 'Mensagem Erro'
);

?>

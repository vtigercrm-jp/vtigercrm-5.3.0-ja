<?php
/* Spanish Translation File
** Author: JPL TSolucio, S.L. Joe Bordes
** Distributed under MPL 1.1
* Es_mx Author: Francisco Hernandez Odin Consultores www.odin.mx
*/
$mod_strings = Array (
'CustomerPortal' => 'Portal Cliente',
'LBL_BASIC_SETTINGS'=>'Configuración Básica',
'LBL_ADVANCED_SETTINGS'=>'Configuración Avanzada',
'LBL_MODULE'=>'Módulo',
'LBL_VIEW_ALL_RECORD'=>'¿Mostrar todos los registros relacionados?',
'YES'=>'Sí',
'NO'=>'No',
'LBL_USER_DESCRIPTION'=>'El usuario arriba seleccionado controlará qué campos aparecen en el Portal de Cliente
				Puedes habilitar/deshabilitar los campos que aparecen en el Portal de Cliente a través de la configuración del perfil.',
'SELECT_USERS'=>'Selecciona los Usuarios',				
'LBL_DISABLE'=>'Deshabilitar',
'LBL_ENABLE' =>'Habilitar',
'Module' => 'Módulo',
'Sequence' =>'Secuencia',
'Visible'=>'Visible'

);

?>

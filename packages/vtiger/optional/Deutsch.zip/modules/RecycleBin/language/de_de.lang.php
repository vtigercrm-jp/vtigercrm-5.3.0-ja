<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 ************************************************************************************/

$mod_strings = Array(
'RecycleBin' => 'Papierkorb',
'MSG_EMPTY_RB_CONFIRMATION'=>'Sind Sie sicher, dass Sie die gelöschten Einträge entgültig aus Ihrem CRM entfernen wollen? Diese Aktion kann nicht rückgängig gemacht werden.',
'LBL_SELECT_MODULE'=>'Modul auswählen',
'LBL_EMPTY_MODULE'=>'Keine Einträge zum Wiederherstellen vorhanden. Modul: ',
'LBL_MASS_RESTORE'=>'Wiederherstellen',
'LBL_EMPTY_RECYCLEBIN'=>'Papierkorb leeren',
'LNK_RESTORE'=>'wiederherstellen',
'LBL_NO_PERMITTED_MODULES'=>'keine berechtigte Module vorhanden',
);

?>
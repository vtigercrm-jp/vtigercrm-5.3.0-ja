<?php
/***********************************************************
*  Module       : Uploads
*  Language     : Francais
*  Version      : 5.1.0 GA*  Created Date : 2009-06-23 21:36:13 
*  Last change  : 2009-07-21 00:49:17
*  Author       : french-vtiger.fr 
*  License      : GPL

***********************************************************/


$mod_strings = Array(
		'LBL_ATTACH_FILE' => 'Pièces jointes',
		'LBL_ATTACH' => 'Ajouter',
		'LBL_CANCEL' => 'Annuler',
		'LBL_STEP_SELECT_FILE' => 'Etape 1 : sélectionnez un fichier',
		'LBL_BROWSE_FILES' => 'Cliquez sur le bouton \"Parcourir\" pour sélectionner un fichier',
		'LBL_DESCRIPTION' => 'Etape 2 : saisissez une description',
		'LBL_OPTIONAL' => '(optionnel)',
);

?>
